#include <linux/types.h>
#include <linux/fs.h>

#include "operafs.h"

//============================================================================


struct file_operations opera_file_operations = {
	.llseek = generic_file_llseek,
	.read = generic_file_read,
	.mmap = generic_file_mmap,
	.readv = generic_file_readv,
	.sendfile = generic_file_sendfile,
};


// ============================================================================


